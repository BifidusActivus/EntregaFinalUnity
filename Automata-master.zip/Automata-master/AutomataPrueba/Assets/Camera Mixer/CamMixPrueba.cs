﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(CameraMixer))]
public class CamMixPrueba : MonoBehaviour
{
    [SerializeField]
    Camera[] cameras;
    CameraMixer mixer;
    // Start is called before the first frame update
    void Start()
    {
        mixer = GetComponent<CameraMixer>();
        mixer.blendCamera(cameras[0], 5.0f, Interpolators.quintIn);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
