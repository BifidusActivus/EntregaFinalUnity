﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour,IEntity
{
    public void EAwake()
    {
        
    }

    public void EUpdate(float delta)
    {

    }


  
}
