﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IEntity 
{

    void EAwake();
    void EUpdate(float delta);

}
